You may want to save these files to disk, then open them in an email client such as Thunderbird or Outlook.
